package net.cozystudios.bebpm.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2331;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

@Mixin(value = class_2331.class, priority = 100)
public class EnchantingTableBlockMixin {

    //? if <1.21 {
    private static final class_6862<class_2248> POWER_PROVIDER_TAG = class_6862.method_40092(
            class_7924.field_41254, new class_2960("minecraft", "enchantment_power_provider")
    );
    //?}

    @Shadow @Final @Mutable
    private static List<class_2338> POWER_PROVIDER_OFFSETS;

    @Inject(method = "<clinit>", at = @At("RETURN"))
    private static void bebpm$expandBookshelfRange(CallbackInfo ci) {
        final int reach = 10;
        final int span = 2 * reach + 1;

        List<class_2338> expanded = new ArrayList<>(span * span * span);
        for (int y = -reach; y <= reach; y++) {
            for (int x = -reach; x <= reach; x++) {
                for (int z = -reach; z <= reach; z++) {
                    if (x == 0 && y == 0 && z == 0) {
                        continue;
                    }
                    expanded.add(new class_2338(x, y, z));
                }
            }
        }
        POWER_PROVIDER_OFFSETS = expanded;
    }

    @Inject(method = "canAccessPowerProvider", at = @At("HEAD"), cancellable = true)
    private static void bebpm$skipAirGapCheck(class_1937 world, class_2338 tablePos, class_2338 providerOffset, CallbackInfoReturnable<Boolean> cir) {
        class_2680 state = world.method_8320(tablePos.method_10081(providerOffset));
        //? if >=1.21 {
        /*if (state.isIn(BlockTags.ENCHANTMENT_POWER_PROVIDER)) {
            cir.setReturnValue(true);
        }
        *///?} else {
        if (state.method_26164(POWER_PROVIDER_TAG)) {
            cir.setReturnValue(true);
        }
        //?}
    }
}
