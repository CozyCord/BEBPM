package net.cozystudios.bebpm.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2331;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3481;

@Mixin(class_2331.class)
public class EnchantingTableBlockMixin {

    //? if <1.21 {
    /*private static final TagKey<Block> POWER_PROVIDER_TAG = TagKey.of(
            RegistryKeys.BLOCK, new Identifier("minecraft", "enchantment_power_provider")
    );
    *///?}

    @Shadow @Final @Mutable
    private static List<class_2338> POWER_PROVIDER_OFFSETS;

    @Inject(method = "<clinit>", at = @At("RETURN"))
    private static void bebpm$expandBookshelfRange(CallbackInfo ci) {
        List<class_2338> expanded = new ArrayList<>();
        for (int y = -3; y <= 10; y++) {
            for (int x = -3; x <= 3; x++) {
                for (int z = -3; z <= 3; z++) {
                    if (Math.abs(x) >= 2 || Math.abs(z) >= 2) {
                        expanded.add(new class_2338(x, y, z));
                    }
                }
            }
        }
        POWER_PROVIDER_OFFSETS = expanded;
    }

    @Inject(method = "canAccessPowerProvider", at = @At("HEAD"), cancellable = true)
    private static void bebpm$skipAirGapCheck(class_1937 world, class_2338 tablePos, class_2338 providerOffset, CallbackInfoReturnable<Boolean> cir) {
        class_2680 state = world.method_8320(tablePos.method_10081(providerOffset));
        //? if >=1.21 {
        cir.setReturnValue(state.method_26164(class_3481.field_44472));
        //?} else {
        /*cir.setReturnValue(state.isIn(POWER_PROVIDER_TAG));
        *///?}
    }
}
